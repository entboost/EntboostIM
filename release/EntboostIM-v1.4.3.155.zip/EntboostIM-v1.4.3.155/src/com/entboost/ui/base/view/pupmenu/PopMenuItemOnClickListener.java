package com.entboost.ui.base.view.pupmenu;

public interface PopMenuItemOnClickListener {
	public void onItemClick();
}
