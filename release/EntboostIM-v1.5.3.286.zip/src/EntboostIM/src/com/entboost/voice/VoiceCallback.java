package com.entboost.voice;

public interface VoiceCallback {

	//没有录音权限
	public abstract void noPermission();
	
}
