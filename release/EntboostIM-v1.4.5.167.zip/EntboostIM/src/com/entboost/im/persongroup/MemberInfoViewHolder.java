package com.entboost.im.persongroup;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MemberInfoViewHolder {
	public ImageButton user_select;
	public ImageView userImg;
	public TextView itemsText;
	public TextView description;
}
